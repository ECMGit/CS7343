​	Student 230125568 hanging out for 4 seconds

​	Student 230662144 hanging out for 4 seconds

​	Student 231198720 hanging out for 4 seconds

​	Student 231735296 hanging out for 4 seconds

​	Student 232271872 hanging out for 4 seconds

​		Student 230125568 takes a seat waiting = 1

Helping a student id = 230125568 for 1 seconds waiting students = 0

The student 230125568 get a grade E

Student 230125568 receiving help

​	Student 230125568 hanging out for 3 seconds

​		Student 231735296 takes a seat waiting = 1

​		Student 230662144 takes a seat waiting = 2

​		Student 232271872 takes a seat waiting = 3

​			Student 231198720 will try later

​	Student 231198720 hanging out for 4 seconds

Helping a student id = 230125568 for 5 seconds waiting students = 2

The student 230125568 get a grade A

Student 231735296 receiving help

​	Student 231735296 hanging out for 4 seconds

​		Student 230125568 takes a seat waiting = 3

​			Student 231198720 will try later

​	Student 231198720 hanging out for 4 seconds

​			Student 231735296 will try later

​	Student 231735296 hanging out for 2 seconds

Helping a student id = 231735296 for 3 seconds waiting students = 2

The student 231735296 get a grade C

Student 230662144 receiving help

​	Student 230662144 hanging out for 3 seconds

​		Student 231735296 takes a seat waiting = 3

​			Student 231198720 will try later

​	Student 231198720 hanging out for 1 seconds

​			Student 231198720 will try later

​	Student 231198720 hanging out for 1 seconds

​			Student 230662144 will try later

​	Student 230662144 hanging out for 3 seconds

Helping a student id = 230662144 for 2 seconds waiting students = 2

The student 230662144 get a grade D

Student 232271872 receiving help

​	Student 232271872 hanging out for 3 seconds

​		Student 231198720 takes a seat waiting = 3

Helping a student id = 232271872 for 1 seconds waiting students = 2

The student 232271872 get a grade E

Student 230125568 receiving help

​	Student 230125568 hanging out for 5 seconds

​		Student 230662144 takes a seat waiting = 3

​			Student 232271872 will try later

​	Student 232271872 hanging out for 2 seconds

Helping a student id = 230125568 for 5 seconds waiting students = 2

The student 230125568 get a grade A

Student 231735296 receiving help

​	Student 231735296 hanging out for 1 seconds

​		Student 231735296 takes a seat waiting = 3

​			Student 232271872 will try later

​	Student 232271872 hanging out for 1 seconds

​			Student 232271872 will try later

​	Student 232271872 hanging out for 2 seconds

​			Student 230125568 will try later

​	Student 230125568 hanging out for 4 seconds

Helping a student id = 231735296 for 2 seconds waiting students = 2

The student 231735296 get a grade D

Student 231198720 receiving help

​	Student 231198720 hanging out for 5 seconds

​		Student 232271872 takes a seat waiting = 3

Helping a student id = 231198720 for 3 seconds waiting students = 2

The student 231198720 get a grade C

Student 230662144 receiving help

​	Student 230662144 hanging out for 1 seconds

​		Student 230125568 takes a seat waiting = 3

​			Student 230662144 will try later

​	Student 230662144 hanging out for 2 seconds

​			Student 231198720 will try later

​	Student 231198720 hanging out for 2 seconds

Helping a student id = 230662144 for 5 seconds waiting students = 2

The student 230662144 get a grade A

Student 231735296 receiving help

​	Student 231735296 hanging out for 2 seconds

​		Student 230662144 takes a seat waiting = 3

​			Student 231198720 will try later

​	Student 231198720 hanging out for 5 seconds

​			Student 231735296 will try later

​	Student 231735296 hanging out for 1 seconds

​			Student 231735296 will try later

​	Student 231735296 hanging out for 5 seconds

Helping a student id = 231735296 for 5 seconds waiting students = 2

The student 231735296 get a grade A

Student 232271872 receiving help

​	Student 232271872 hanging out for 2 seconds

​		Student 231198720 takes a seat waiting = 3

​			Student 232271872 will try later

​	Student 232271872 hanging out for 5 seconds

​			Student 231735296 will try later

​	Student 231735296 hanging out for 5 seconds

Helping a student id = 232271872 for 4 seconds waiting students = 2

The student 232271872 get a grade B

Student 230125568 receiving help

​	Student 230125568 hanging out for 4 seconds

​		Student 232271872 takes a seat waiting = 3

​			Student 231735296 will try later

​	Student 231735296 hanging out for 3 seconds

Helping a student id = 230125568 for 1 seconds waiting students = 2

The student 230125568 get a grade E

​		Student 230125568 takes a seat waiting = 3

Student 230662144 receiving help

​	Student 230662144 hanging out for 1 seconds

​			Student 230662144 will try later

​	Student 230662144 hanging out for 2 seconds

Helping a student id = 230662144 for 2 seconds waiting students = 2

The student 230662144 get a grade D

Student 231198720 receiving help

​	Student 231198720 hanging out for 4 seconds

​		Student 231735296 takes a seat waiting = 3

​			Student 230662144 will try later

​	Student 230662144 hanging out for 4 seconds

Helping a student id = 231198720 for 3 seconds waiting students = 2

The student 231198720 get a grade C

Student 232271872 receiving help

​	Student 232271872 hanging out for 5 seconds

​		Student 231198720 takes a seat waiting = 3

Helping a student id = 232271872 for 3 seconds waiting students = 2

The student 232271872 get a grade C

Student 230125568 receiving help

​	Student 230125568 hanging out for 5 seconds

​		Student 230662144 takes a seat waiting = 3

​			Student 232271872 will try later

​	Student 232271872 hanging out for 3 seconds

Helping a student id = 230125568 for 4 seconds waiting students = 2

The student 230125568 get a grade B

Student 231735296 receiving help

​	Student 231735296 hanging out for 4 seconds

​		Student 232271872 takes a seat waiting = 3

​			Student 230125568 will try later

​	Student 230125568 hanging out for 1 seconds

​			Student 230125568 will try later

​	Student 230125568 hanging out for 1 seconds

Helping a student id = 231735296 for 3 seconds waiting students = 2

The student 231735296 get a grade C

​		Student 231735296 takes a seat waiting = 3

Student 231198720 receiving help

​	Student 231198720 hanging out for 1 seconds

​			Student 230125568 will try later

​	Student 230125568 hanging out for 2 seconds

​			Student 231198720 will try later

​	Student 231198720 hanging out for 4 seconds

​			Student 230125568 will try later

​	Student 230125568 hanging out for 5 seconds

Helping a student id = 231198720 for 1 seconds waiting students = 2

The student 231198720 get a grade E

Student 230662144 receiving help

​	Student 230662144 hanging out for 1 seconds

Student 232271872 receiving help

​	Student 232271872 hanging out for 2 seconds

Helping a student id = 232271872 for 2 seconds waiting students = 1

The student 232271872 get a grade D

​		Student 230662144 takes a seat waiting = 2

​		Student 231198720 takes a seat waiting = 3

​			Student 232271872 will try later

​	Student 232271872 hanging out for 2 seconds

Helping a student id = 232271872 for 4 seconds waiting students = 2

The student 232271872 get a grade B

Student 231735296 receiving help

​		Student 230125568 takes a seat waiting = 3

​			Student 232271872 will try later

​	Student 232271872 hanging out for 3 seconds

Helping a student id = 231735296 for 2 seconds waiting students = 2

The student 231735296 get a grade D

Student 230662144 receiving help

​		Student 232271872 takes a seat waiting = 3

Helping a student id = 230662144 for 4 seconds waiting students = 2

The student 230662144 get a grade B

Student 231198720 receiving help

​	Student 231198720 hanging out for 2 seconds

​		Student 231198720 takes a seat waiting = 3

Helping a student id = 231198720 for 1 seconds waiting students = 2

The student 231198720 get a grade E

Student 230125568 receiving help

Helping a student id = 230125568 for 4 seconds waiting students = 1

The student 230125568 get a grade B

Student 232271872 receiving help

Helping a student id = 232271872 for 2 seconds waiting students = 0

The student 232271872 get a grade D

Student 231198720 receiving help